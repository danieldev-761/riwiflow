import { defineConfig } from 'vite';

export default defineConfig({
  appType: 'spa',
  server: {
    historyApiFallback: true,
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, ''),
      },
    },
  },
  preview: {
    historyApiFallback: true,
  },
});
