// js/layout.js — Shell compartido de la SPA (sidebar + header)
//
// CAMBIO (nuevo archivo): Este módulo monta el layout base UNA SOLA VEZ
// y expone renderView(html) para que cada vista solo reemplace el
// contenido de #board-scroll sin destruir el sidebar ni el header.
// Esto elimina el parpadeo al navegar entre Dashboard y Team.

import { getSession, clearSession } from "./auth.js";
import { navigate } from "./router.js";

let layoutMounted = false;

// Rutas que usan el shell (sidebar + header)
// Login NO usa el shell — tiene su propio layout de pantalla completa
export const SHELL_ROUTES = ["/dashboard", "/team"];

// ─────────────────────────────────────────────────────────────────────────────
// mountShell — construye sidebar + header en #app si aún no están montados.
// Si el shell ya existe, solo actualiza qué enlace del sidebar está activo.
// ─────────────────────────────────────────────────────────────────────────────
export function mountShell(activePath) {
  const container = document.getElementById("app");
  const currentUser = getSession();
  const isAdmin = currentUser?.role === "admin";

  // Clases del contenedor — iguales a las que usaba dashboard.js
  document.body.className =
    "bg-background text-on-background overflow-hidden h-screen flex";
  container.className =
    "bg-background text-on-background overflow-hidden h-screen flex w-full";

  if (layoutMounted && document.getElementById("board-scroll")) {
    // El shell ya existe: solo actualizar el nav activo
    updateActiveNav(activePath);
    return;
  }

  // Primera vez: construir el shell completo
  const sidebarHTML = buildSidebar(isAdmin, activePath);
  const mainHTML = buildMain(isAdmin);

  container.innerHTML = sidebarHTML + mainHTML;
  layoutMounted = true;

  // ── Listeners del shell (se registran una sola vez) ──────────────────────
  document.getElementById("logout-btn").addEventListener("click", () => {
    layoutMounted = false; // resetear para cuando vuelva a loguear
    clearSession();
    navigate("/login");
  });

  document.getElementById("nav-dashboard").addEventListener("click", () =>
    navigate("/dashboard")
  );
  document.getElementById("nav-team").addEventListener("click", () =>
    navigate("/team")
  );

  if (isAdmin) {
    // El botón del sidebar cambia según la vista activa; se maneja en cada vista
    document.getElementById("shell-action-btn")?.addEventListener("click", () => {
      // Disparar evento custom para que la vista activa lo intercepte
      window.dispatchEvent(new CustomEvent("shell:action"));
    });
  }

  document.getElementById("modal-overlay").addEventListener("click", (e) => {
    if (e.target.id === "modal-overlay") closeModal();
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// renderView — reemplaza SOLO el contenido de #board-scroll
// ─────────────────────────────────────────────────────────────────────────────
export function renderView(html) {
  const boardScroll = document.getElementById("board-scroll");
  if (boardScroll) boardScroll.innerHTML = html;
}

// ─────────────────────────────────────────────────────────────────────────────
// getSearchInput — devuelve el input de búsqueda del header
// ─────────────────────────────────────────────────────────────────────────────
export function getSearchInput() {
  return document.getElementById("search-input");
}

// ─────────────────────────────────────────────────────────────────────────────
// Modal helpers compartidos
// ─────────────────────────────────────────────────────────────────────────────
export function openModal(innerHTML) {
  const box = document.getElementById("modal-box");
  if (box) box.innerHTML = innerHTML;
  document.getElementById("modal-overlay")?.classList.remove("hidden");
}

export function closeModal() {
  document.getElementById("modal-overlay")?.classList.add("hidden");
}

// ─────────────────────────────────────────────────────────────────────────────
// updateSidebarActionBtn — cada vista personaliza el botón inferior del sidebar
// ─────────────────────────────────────────────────────────────────────────────
export function updateSidebarActionBtn({ icon, label }) {
  const btn = document.getElementById("shell-action-btn");
  if (btn) {
    btn.innerHTML = `
      <span class="material-symbols-outlined">${icon}</span>
      ${label}
    `;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// updateSearchPlaceholder
// ─────────────────────────────────────────────────────────────────────────────
export function updateSearchPlaceholder(text) {
  const input = document.getElementById("search-input");
  if (input) input.placeholder = text;
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVADOS
// ─────────────────────────────────────────────────────────────────────────────
function updateActiveNav(activePath) {
  const navMap = {
    "/dashboard": "nav-dashboard",
    "/team": "nav-team",
  };

  // Quitar estado activo de todos
  Object.values(navMap).forEach((id) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.className =
      "flex items-center text-secondary hover:text-primary hover:bg-primary-container/10 px-4 py-3 mx-2 font-body-sm text-body-sm rounded-lg transition-all cursor-pointer";
  });

  // Poner activo el correspondiente
  const activeId = navMap[activePath];
  if (activeId) {
    const el = document.getElementById(activeId);
    if (el)
      el.className =
        "flex items-center bg-primary-fixed text-on-primary-fixed-variant rounded-lg mx-2 px-4 py-3 font-body-sm text-body-sm transition-all scale-[0.98] cursor-pointer";
  }
}

function buildSidebar(isAdmin, activePath) {
  const dashActive =
    activePath === "/dashboard"
      ? "bg-primary-fixed text-on-primary-fixed-variant rounded-lg mx-2 px-4 py-3 font-body-sm text-body-sm transition-all scale-[0.98] cursor-pointer"
      : "text-secondary hover:text-primary hover:bg-primary-container/10 px-4 py-3 mx-2 font-body-sm text-body-sm rounded-lg transition-all cursor-pointer";

  const teamActive =
    activePath === "/team"
      ? "bg-primary-fixed text-on-primary-fixed-variant rounded-lg mx-2 px-4 py-3 font-body-sm text-body-sm transition-all scale-[0.98] cursor-pointer"
      : "text-secondary hover:text-primary hover:bg-primary-container/10 px-4 py-3 mx-2 font-body-sm text-body-sm rounded-lg transition-all cursor-pointer";

  return `
    <aside class="hidden md:flex flex-col pt-md pb-xl gap-xs h-full bg-surface-container-low border-r border-outline-variant w-[280px] shrink-0">
      <div class="px-gutter mb-xl">
        <h1 class="font-headline-md text-headline-md font-bold text-primary">Riwiflow</h1>
        <p class="font-body-sm text-body-sm text-on-surface-variant">Product Team</p>
      </div>
      <nav class="flex-1 space-y-1">
        <a id="nav-dashboard" class="flex items-center ${dashActive}">
          <span class="material-symbols-outlined mr-3">dashboard</span>
          <span>Dashboard</span>
        </a>
        <a class="flex items-center text-secondary hover:text-primary hover:bg-primary-container/10 px-4 py-3 mx-2 font-body-sm text-body-sm rounded-lg transition-all" href="#">
          <span class="material-symbols-outlined mr-3">assignment</span>
          <span>Projects</span>
        </a>
        <a id="nav-team" class="flex items-center ${teamActive}">
          <span class="material-symbols-outlined mr-3">group</span>
          <span>Team</span>
        </a>
        <a class="flex items-center text-secondary hover:text-primary hover:bg-primary-container/10 px-4 py-3 mx-2 font-body-sm text-body-sm rounded-lg transition-all" href="#">
          <span class="material-symbols-outlined mr-3">bar_chart</span>
          <span>Reports</span>
        </a>
        <a class="flex items-center text-secondary hover:text-primary hover:bg-primary-container/10 px-4 py-3 mx-2 font-body-sm text-body-sm rounded-lg transition-all" href="#">
          <span class="material-symbols-outlined mr-3">settings</span>
          <span>Settings</span>
        </a>
      </nav>
      <div class="px-4 mt-auto">
        ${isAdmin ? `
          <button id="shell-action-btn" class="w-full bg-primary text-on-primary py-3 rounded-xl font-label-md text-label-md flex items-center justify-center gap-2 shadow-sm hover:opacity-90 transition-opacity">
            <span class="material-symbols-outlined">add</span>
            New Project
          </button>
        ` : ""}
      </div>
    </aside>
  `;
}

function buildMain(isAdmin) {
  return `
    <main class="flex-1 flex flex-col min-w-0">
      <header class="flex justify-between items-center h-16 px-gutter w-full bg-surface border-b border-outline-variant z-40">
        <div class="flex items-center gap-4 flex-1">
          <div class="relative max-w-md w-full">
            <span class="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-outline">search</span>
            <input
              id="search-input"
              class="w-full pl-10 pr-4 py-2 bg-surface-container border border-outline-variant rounded-full font-body-md text-body-md focus:outline-none focus:ring-2 focus:ring-primary/20"
              placeholder="Search tasks or files..."
              type="text"
            />
          </div>
        </div>
        <div class="flex items-center gap-4 ml-4">
          <button class="material-symbols-outlined text-on-surface-variant hover:bg-surface-container-low p-2 rounded-full transition-colors">notifications</button>
          <button class="material-symbols-outlined text-on-surface-variant hover:bg-surface-container-low p-2 rounded-full transition-colors">help_outline</button>
          <img
            id="logout-btn"
            alt="User profile"
            class="w-8 h-8 rounded-full border border-outline-variant object-cover cursor-pointer"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuC2-sF_Qd9jEF33fUrS3vMvdoA8rbw2_a6jzv7r_6oDikCkrertidHwLgqAtWuKvLnRx7Lcsi79ZYj4FBaL_pETFxeyeF27_PhXy-KnuioiYgCwYTKcWDEuZoRksSf8Jb0_ZmsxJkpTFGZ2bW8aTl5fhcA4DOHQQal_vu1KVBcizoM56dHRc7Ce_vkUul2aL96DSeDmqR4YdfGUuoIQkUF_F8AX45U05tmCFg7YyPH6xtgAx7e31u5_5e2rQxm_tgBEgnhV-LsqsEDH"
            title="Logout"
          />
        </div>
      </header>

      <!-- Solo este div cambia al navegar entre vistas -->
      <div class="flex-1 overflow-x-auto p-gutter custom-scrollbar" id="board-scroll">
        <!-- El contenido lo inyecta cada vista -->
      </div>
    </main>

    <!-- Modal Overlay compartido — nunca se destruye -->
    <div id="modal-overlay" class="hidden fixed inset-0 bg-inverse-surface/40 z-50 flex items-center justify-center p-gutter">
      <div id="modal-box" class="bg-surface rounded-xl border border-outline-variant shadow-xl w-full max-w-lg"></div>
    </div>
  `;
}
