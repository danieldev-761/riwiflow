// router.js — SPA routing (History API) with Auth Guards
//
// CAMBIO: Se importa team.js como nueva vista registrada en /team.
// La ruta /team está protegida igual que /dashboard.

import login from "../views/login.js";
import db from "../views/dashboard.js";
import team from "../views/team.js";          // CAMBIO: nueva vista Team
import { isLoggedIn } from "./auth.js";

// Map of route paths to render functions
const routes = {
  "/": login,
  "/login": login,
  "/dashboard": db,
  "/team": team,                              // CAMBIO: ruta registrada
};

// Navigate to a given route programmatically
export function navigate(path) {
  window.history.pushState({}, "", path);
  router();
}

export function router() {
  const path     = window.location.pathname;
  const loggedIn = isLoggedIn();

  // CAMBIO: /team también requiere autenticación
  if ((path === "/dashboard" || path === "/team") && !loggedIn) {
    navigate("/login");
    return;
  }

  // If trying to access login (or /) WITH credentials, send to dashboard
  if ((path === "/login" || path === "/") && loggedIn) {
    navigate("/dashboard");
    return;
  }

  const page = routes[path] || routes["/"];
  if (page) page.mounted();
}