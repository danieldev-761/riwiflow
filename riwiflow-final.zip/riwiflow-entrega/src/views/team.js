// views/team.js — CRUD de usuarios (vista Team)
//
// CAMBIO: Usa js/layout.js (mountShell + renderView) igual que dashboard.js.
// El shell (sidebar + header) ya está montado y no se toca.
// Solo se reemplaza el contenido de #board-scroll, eliminando cualquier
// parpadeo o recarga de layout al navegar entre vistas.

import { getAllUsers, createUser, updateUser, deleteUser } from "../js/api.js";
import { getSession } from "../js/auth.js";
import {
  mountShell,
  renderView,
  openModal,
  closeModal,
  updateSidebarActionBtn,
  updateSearchPlaceholder,
} from "../js/layout.js";

let currentUser = null;
let allUsers    = [];

const team = {
  mounted: async () => {
    currentUser = getSession();
    const isAdmin = currentUser.role === "admin";

    // Shell ya existe o se monta; solo cambia el nav activo a "Team"
    mountShell("/team");

    if (isAdmin) {
      updateSidebarActionBtn({ icon: "person_add", label: "New User" });
      window.removeEventListener("shell:action", handleShellAction);
      window.addEventListener("shell:action", handleShellAction);
    }
    updateSearchPlaceholder("Search users…");

    // Loading skeleton
    renderView(`
      <div class="flex-1 flex items-center justify-center h-full">
        <div class="text-center space-y-md">
          <span class="material-symbols-outlined text-primary text-5xl animate-spin">progress_activity</span>
          <p class="font-body-md text-body-md text-on-surface-variant">Loading team…</p>
        </div>
      </div>
    `);

    try {
      allUsers = await getAllUsers();
    } catch {
      renderView(`
        <div class="flex-1 flex items-center justify-center h-full">
          <div class="text-center space-y-md p-xl bg-error-container rounded-xl max-w-md">
            <span class="material-symbols-outlined text-error text-4xl">wifi_off</span>
            <p class="font-headline-md text-headline-md text-error">Cannot connect to server</p>
            <p class="font-body-md text-body-md text-on-surface-variant">
              Make sure json-server is running:<br>
              <code class="bg-surface px-sm py-xs rounded font-mono text-primary">npx json-server db.json</code>
            </p>
          </div>
        </div>
      `);
      return;
    }

    renderTeam();
    bindSearchInput();
  },
};

function handleShellAction() {
  openUserModal(null);
}

// ─────────────────────────────────────────────────────────────────────────────
// Renderiza la tabla de usuarios en #board-scroll
// ─────────────────────────────────────────────────────────────────────────────
function renderTeam() {
  const isAdmin = currentUser.role === "admin";

  renderView(`
    <div class="w-full" id="team-content">
      <div class="flex items-center justify-between mb-lg">
        <div class="flex items-center gap-3">
          <h2 class="font-headline-md text-headline-md text-on-surface">Team Members</h2>
          <span class="bg-primary-container text-on-primary px-2 py-0.5 rounded-full font-label-sm text-label-sm" id="user-count">
            ${allUsers.length}
          </span>
        </div>
        ${isAdmin ? `
          <button id="new-user-btn-top" class="flex items-center gap-2 bg-primary text-on-primary px-lg py-sm rounded-xl font-label-md text-label-md shadow-sm hover:opacity-90 transition-opacity">
            <span class="material-symbols-outlined text-[18px]">person_add</span>
            Add User
          </button>
        ` : ""}
      </div>

      <div class="bg-surface border border-outline-variant rounded-xl overflow-hidden shadow-sm">
        <div class="grid grid-cols-[auto_1fr_1fr_auto_auto] items-center gap-4 px-lg py-md bg-surface-container-low border-b border-outline-variant font-label-md text-label-md text-on-surface-variant">
          <span></span>
          <span>Name</span>
          <span>Email</span>
          <span>Role</span>
          ${isAdmin ? `<span class="text-center">Actions</span>` : ""}
        </div>
        <div id="user-list">
          ${allUsers.map(u => renderUserRow(u, isAdmin)).join("")}
        </div>
        ${allUsers.length === 0 ? `
          <div class="text-center py-xl text-on-surface-variant font-body-sm text-body-sm">No users found</div>
        ` : ""}
      </div>
    </div>
  `);

  attachUserListeners();
}

function renderUserRow(user, isAdmin) {
  const initials  = user.name.split(" ").map(n => n[0]).slice(0, 2).join("").toUpperCase();
  const roleClass = user.role === "admin"
    ? "bg-primary-fixed text-on-primary-fixed-variant"
    : "bg-surface-container-high text-on-surface-variant";
  const isSelf = String(user.id) === String(currentUser.id);

  return `
    <div class="user-row grid grid-cols-[auto_1fr_1fr_auto_auto] items-center gap-4 px-lg py-md border-b border-outline-variant last:border-b-0 hover:bg-surface-container-low/50 transition-colors"
         data-user-id="${user.id}" data-name="${user.name.toLowerCase()}" data-email="${user.email.toLowerCase()}">
      <div class="w-9 h-9 rounded-full bg-primary-fixed text-on-primary-fixed-variant flex items-center justify-center text-[12px] font-bold border-2 border-surface shrink-0">
        ${initials}
      </div>
      <div>
        <p class="font-label-md text-label-md text-on-surface">${user.name}</p>
        ${isSelf ? `<span class="font-body-sm text-body-sm text-primary">(You)</span>` : ""}
      </div>
      <p class="font-body-sm text-body-sm text-on-surface-variant truncate">${user.email}</p>
      <span class="${roleClass} px-2 py-0.5 rounded-full font-label-sm text-label-sm capitalize">${user.role}</span>
      ${isAdmin ? `
        <div class="flex items-center gap-1 justify-end">
          <button class="btn-edit-user material-symbols-outlined text-outline hover:text-primary text-sm p-1.5 rounded-lg hover:bg-surface-container transition-colors"
                  data-id="${user.id}" title="Edit user">edit</button>
          <button class="btn-delete-user material-symbols-outlined text-outline hover:text-error text-sm p-1.5 rounded-lg hover:bg-surface-container transition-colors ${isSelf ? "opacity-40 cursor-not-allowed" : ""}"
                  data-id="${user.id}" title="${isSelf ? "Cannot delete yourself" : "Delete user"}" ${isSelf ? "disabled" : ""}>delete</button>
        </div>
      ` : "<span></span>"}
    </div>
  `;
}

function attachUserListeners() {
  document.querySelectorAll(".btn-edit-user").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const user = allUsers.find(u => String(u.id) === String(btn.dataset.id));
      if (user) openUserModal(user);
    });
  });

  document.querySelectorAll(".btn-delete-user").forEach((btn) => {
    if (btn.disabled) return;
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      openDeleteConfirmation(btn.dataset.id);
    });
  });

  document.getElementById("new-user-btn-top")?.addEventListener("click", () => openUserModal(null));
}

function bindSearchInput() {
  const input = document.getElementById("search-input");
  if (!input) return;
  const fresh = input.cloneNode(true);
  input.parentNode.replaceChild(fresh, input);
  fresh.addEventListener("input", (e) => {
    filterUsers(e.target.value.trim().toLowerCase());
  });
}

function filterUsers(query) {
  document.querySelectorAll(".user-row").forEach((row) => {
    const name  = row.dataset.name  || "";
    const email = row.dataset.email || "";
    row.style.display = (name.includes(query) || email.includes(query)) ? "" : "none";
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// Modal crear / editar usuario
// ─────────────────────────────────────────────────────────────────────────────
function openUserModal(user = null) {
  const isEditing = Boolean(user);

  openModal(`
    <form id="user-form" onsubmit="return false;">
      <div class="flex items-center justify-between px-xl pt-xl pb-lg border-b border-outline-variant">
        <h2 class="font-headline-md text-headline-md text-on-surface">${isEditing ? "Edit User" : "New User"}</h2>
        <button id="modal-close" type="button" class="material-symbols-outlined text-on-surface-variant hover:bg-surface-container-low p-1 rounded-full">close</button>
      </div>
      <div class="px-xl py-lg space-y-lg">
        <p id="user-error" class="hidden text-error font-body-sm text-body-sm bg-error-container px-md py-sm rounded-lg"></p>
        <div class="space-y-sm">
          <label class="font-label-md text-label-md text-on-surface" for="f-name">Full Name</label>
          <input id="f-name" type="text" value="${isEditing ? user.name : ""}" required
            class="w-full px-md py-md bg-white border border-outline-variant rounded-lg font-body-md text-body-md text-on-surface input-focus-ring"/>
        </div>
        <div class="space-y-sm">
          <label class="font-label-md text-label-md text-on-surface" for="f-email">Email</label>
          <input id="f-email" type="email" value="${isEditing ? user.email : ""}" required
            class="w-full px-md py-md bg-white border border-outline-variant rounded-lg font-body-md text-body-md text-on-surface input-focus-ring"/>
        </div>
        <div class="space-y-sm">
          <label class="font-label-md text-label-md text-on-surface" for="f-password">
            ${isEditing ? "Password (leave blank to keep current)" : "Password"}
          </label>
          <input id="f-password" type="password" ${!isEditing ? "required" : ""}
            class="w-full px-md py-md bg-white border border-outline-variant rounded-lg font-body-md text-body-md text-on-surface input-focus-ring"
            placeholder="${isEditing ? "••••••••" : ""}"/>
        </div>
        <div class="space-y-sm">
          <label class="font-label-md text-label-md text-on-surface" for="f-role">Role</label>
          <select id="f-role" class="w-full px-md py-md bg-white border border-outline-variant rounded-lg font-body-md text-body-md text-on-surface input-focus-ring">
            <option value="coder" ${isEditing && user.role === "coder" ? "selected" : ""}>Coder</option>
            <option value="admin" ${isEditing && user.role === "admin" ? "selected" : ""}>Admin</option>
          </select>
        </div>
      </div>
      <div class="flex items-center justify-end gap-sm px-xl pb-xl">
        <button id="modal-cancel" type="button"
          class="px-lg py-md border border-outline-variant rounded-lg font-label-md text-label-md text-on-surface hover:bg-surface-container-low transition-colors">Cancel</button>
        <button id="modal-save" type="submit"
          class="px-lg py-md bg-primary text-on-primary rounded-lg font-label-md text-label-md flex items-center gap-sm hover:opacity-90 active:scale-[0.98] transition-all">
          <span class="material-symbols-outlined text-[18px]">${isEditing ? "save" : "person_add"}</span>
          ${isEditing ? "Save changes" : "Create user"}
        </button>
      </div>
    </form>
  `);

  document.getElementById("modal-close").addEventListener("click", closeModal);
  document.getElementById("modal-cancel").addEventListener("click", closeModal);
  document.getElementById("user-form").addEventListener("submit", () => handleSaveUser(user, isEditing));
}

function openDeleteConfirmation(userId) {
  const user = allUsers.find(u => String(u.id) === String(userId));

  openModal(`
    <div class="px-xl pt-xl pb-lg space-y-md">
      <div class="flex items-center gap-md text-error">
        <span class="material-symbols-outlined text-3xl">person_remove</span>
        <h2 class="font-headline-md text-headline-md">Delete User?</h2>
      </div>
      <p class="font-body-md text-body-md text-on-surface-variant">
        You are about to permanently delete <strong>${user?.name ?? "this user"}</strong>.
        This action cannot be undone.
      </p>
    </div>
    <div class="flex items-center justify-end gap-sm px-xl pb-xl">
      <button id="confirm-cancel"
        class="px-lg py-md border border-outline-variant rounded-lg font-label-md text-label-md text-on-surface hover:bg-surface-container-low transition-colors">Cancel</button>
      <button id="confirm-delete"
        class="px-lg py-md bg-error text-on-error rounded-lg font-label-md text-label-md hover:opacity-90 active:scale-[0.98] transition-all flex items-center gap-sm">
        <span class="material-symbols-outlined text-[18px]">delete</span>
        Delete
      </button>
    </div>
  `);

  document.getElementById("confirm-cancel").addEventListener("click", closeModal);
  document.getElementById("confirm-delete").addEventListener("click", async () => {
    const delBtn = document.getElementById("confirm-delete");
    delBtn.disabled = true;
    delBtn.innerHTML = "Deleting…";
    await handleDeleteUser(userId);
    closeModal();
  });
}

async function handleSaveUser(user, isEditing) {
  const saveBtn  = document.getElementById("modal-save");
  const name     = document.getElementById("f-name").value.trim();
  const email    = document.getElementById("f-email").value.trim();
  const password = document.getElementById("f-password").value;
  const role     = document.getElementById("f-role").value;

  if (!name)  { showModalError("Name is required.");  return; }
  if (!email) { showModalError("Email is required."); return; }
  if (!isEditing && !password) { showModalError("Password is required."); return; }

  const emailExists = allUsers.some(u => u.email === email && String(u.id) !== String(user?.id));
  if (emailExists) { showModalError("This email is already in use."); return; }

  saveBtn.disabled = true;
  saveBtn.innerHTML = `<span class="material-symbols-outlined text-[18px] animate-spin">progress_activity</span> Saving…`;

  try {
    if (isEditing) {
      const payload = { name, email, role };
      if (password) payload.password = password;
      const updated = await updateUser(user.id, payload);
      const idx = allUsers.findIndex(u => u.id === user.id);
      allUsers[idx] = updated;
    } else {
      const created = await createUser({ name, email, password, role });
      allUsers.push(created);
    }
    closeModal();
    renderTeam();
    bindSearchInput();
  } catch {
    showModalError("Error saving user. Please check your connection.");
    saveBtn.disabled = false;
    saveBtn.innerHTML = `
      <span class="material-symbols-outlined text-[18px]">${isEditing ? "save" : "person_add"}</span>
      ${isEditing ? "Save changes" : "Create user"}
    `;
  }
}

async function handleDeleteUser(userId) {
  try {
    await deleteUser(userId);
    allUsers = allUsers.filter(u => String(u.id) !== String(userId));
    renderTeam();
    bindSearchInput();
  } catch {
    console.error("Error deleting user.");
  }
}

function showModalError(msg) {
  const errorEl = document.getElementById("user-error");
  if (errorEl) { errorEl.textContent = msg; errorEl.classList.remove("hidden"); }
}

export default team;